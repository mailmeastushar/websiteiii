@include('front/header')


 @yield('container')


@include('front/footer')