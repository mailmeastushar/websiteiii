@extends('front/master')

@section("meta_title",$data->meta_title)
@section("meta_keywords",$data->meta_keywords)
@section("meta_description",$data->meta_description)

@section('container')



<h3 style="text-align: center;margin-top: 25px;">{{ $data['name'] }}</h3>
<div class="information">
<div class="container">
<div class="row">
<div class="col-xl">
<p style="color: black;text-align: justify;">
	{!! $data['description'] !!}
</p>
</div>
</div>

</div>


@endsection