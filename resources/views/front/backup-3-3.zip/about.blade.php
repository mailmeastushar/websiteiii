@extends('front.master')

@section("meta_title",$data->meta_title)
@section("meta_keywords",$data->meta_keywords)
@section("meta_description","Triple I Business is one of the leading visa and immigration consultancies in India helping Students, Skilled workers to get a PR visa, Study Visa, & Work Visa.")
@section('container')


@if(!empty($data['image']))
<div class="abtImg">
	<img src="{{ asset('public/assets/images/'.$data['image'] )}}" style="width: 100%" height="450" alt="{{ $data['alt'] }}" class="img-responsive">
</div>
			
@endif

<div class="more-info about-info">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="more-info-content">
              <div class="row">
                <div class="col-md-6 align-self-center">
                  <div class="right-content">
                    <!--<span>our solid background on finance</span>-->
                    <h2>Get to know about <em>our company</em></h2>
                    <p>Triple I Business is one of the growing companies in Delhi NCR, providing consultancy services for Permanent Residency and Study Visas in Canada, Australia, Germany, UK, and many other countries. We also offer Visa services for Tourist visas and Visitor visas.</p>

<p>Established in 2014 with a vision to bring transparency to Visa seekers in India, we found that Visa Seekers in India are facing a bunch of issues. There is a lack of information in the process, transparency is missing, mis-selling is on an all-time high. Our purpose is to curb the issues in the immigration and visa process, faced by Visa Seekers. We offer visa seekers an opportunity to connect verified Immigration consultants from Canada, Australia, Germany, and the UK, and let the papers be handled by experts in the Immigration Industry.</p>

                  </div>
                </div>
                <div class="col-md-6">
                  <div class="left-image">
                    <img src="https://kushalscreeningservices.com/images/about-image.jpg" alt="Best Visa Consultants in India">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<div class="about_custom abt-page">
<div class="container">
<div class="row">
    
    <div class="col-md-4">
        <div class="innerABT">
            <h6  >Vision</h6>
            <p>
Triple I Business envisions providing authentic information, ease of communication, and standard guidance to every aspirant who wishes to settle abroad. </p>

        </div>
    </div>
     <div class="col-md-4">
        <div class="innerABT">
             <h6  >Mission</h6>
             <p>Triple I Business is founded by young entrepreneurs who understand the value of Customer Relationships and Trust. Triple I offers flexible payment options for visa Seekers to process their applications without putting a burden in their pockets. young entrepreneurs who understand the value of customer relationship and Trust, Triple I offers </p>

 

        </div>
    </div>
     <div class="col-md-4"><div class="innerABT">
        <h6>OUR CORE VALUES</h6>
        <p>
            Triple I stand for “Intention” “Integrity” and “Impact”.  We believe anything is done with good intention and honest integrity definitely has a positive impact to make the world better. 

        </p>
        <p><i class="fa fa-check" aria-hidden="true" style="font-size: 0.8em;color: #28cce1;"></i> Customer First</p>

<p><i class="fa fa-check" aria-hidden="true" style="font-size: 0.8em;color: #28cce1;"></i> Transparency</p>

<p><i class="fa fa-check" aria-hidden="true" style="font-size: 0.8em;color: #28cce1;"></i> Making Visa Processing Secured</p>
</div>
    </div>
<!--<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">-->
 

<!--<h2>Who We Are?</h2> -->
<!--<p>Triple I Business is one of the growing companies in Delhi NCR providing Consultancy services for Permanent Residency and Study visas in Canada, Australia, Germany, UK, and many other countries, we also offer Visa services for Tourist Visas and Visitor Visa.</p>-->

<!--<p>Established in 2014 with a vision to bring transparency to Visa seeker in India, We found that Visa Seekers in India is facing a lot of issues, there is a lack of information on the process, transparency is missing, mis-selling is on the all-time high and our purpose is to curb the issues in the immigration and visa process faced by Visa Seekers. We offer visa seekers an opportunity to connect verified Immigration consultants from Canada, Australia, Germany, and the UK and let the papers handled by the experts in Immigration Industry.</p>-->


<!--</div>-->
<!--<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12info_section">-->

<!-- <h6 style="font-weight: bold">Vision</h6 style="font-weight: bold">-->
<!--<p>-->
<!--Triple I Business work with accredited immigration lawyers from Canada, Australia, Germany, and the UK, we offer visa seekers the opportunities to connect with verified Immigration consultants and let the papers handled by the experts in Immigration Industry.</p>-->

 
<!-- <h6 style="font-weight: bold">Mission</h6 style="font-weight: bold">-->
<!--<p>Triple I Business is founded by young entrepreneurs who understand the value of customer relationship and Trust, Triple I offers flexible payment options for the visa Seekers to process their application without putting a burden in their pockets young entrepreneurs who understand the value of customer relationship and Trust, Triple I offers .</p>-->

 




</div>
<!--<div class="col-xl">-->
<!--	<h5 style="font-weight: bold;">OUR CORE VALUES</h5>-->
<!--	<p>-->
<!--Triple I stand for “Intention” “Integrity” and “Impact” we believe that if we do anything with good intention and show honest integrity, it will definitely have a positive impact to make the world better.</p>-->
<!--<p><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Customer First</p>-->

<!--<p><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Transparency</p>-->

<!--<p><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Making Visa Processing Secured</p>-->
	
<!--</div>-->


</div>
@if(!empty($data['image']))
<h5 style="margin-top: 25px;font-weight: bold">{{ $data['name'] }}</h5>
@else
<h5 style="margin-top: -15px;font-weight: bold">{{ $data['name'] }}</h5>
@endif

	{!! $data['description'] !!}
</div>
<div class="service-slideArea">
<div class="container">

   <div class="abt-info2">
         <div class="row">
            <div class="col-md-6">
               <div class="themestek-wrap-cell">
                  <h4 class="themestek-custom-heading ">CHOOSE YOUR VISA </h4>
                  <h2 class="themestek-custom-heading ">We provide our Experts to<br>
                     <em>Generate Great visa</em>
                  </h2>
               </div>
            </div>
            <div class="col-md-6">
               <div class="wpb_wrapper">
                  <p>We have been counselling students for educational opportunities in Foreign countries.</p>
               </div>
            </div>
         </div>
      </div>

 <div class="owl-carousel owl-theme" id="service-slide-new">
      <div class="item">
         <div class="insed-service">
            <h4>PR Visa</h4>
            <div class="icon-service">
               <img src="{{ asset('public/assets/user') }}/new-icon/business-visa.png" alt="visa-icon"> 
            </div>
            <div class="basciInfo">
              Become a permanent residence of Canada, Australia, UK, Germany & New Zealand
            </div>
            <a href="#"></a>
         </div>
      </div>
      <div class="item">
         <div class="insed-service">
            <h4>Student  Visa</h4>
            <div class="icon-service">
               <img src="{{ asset('public/assets/user') }}/new-icon/consler-visa.png" alt="visa-icon"> 
            </div>
            <div class="basciInfo">
             Broaden your Career with abundant study opportunities
            </div>
            <a href="#"></a>
         </div>
      </div>
      <div class="item">
         <div class="insed-service">
            <h4>Family  Visa</h4>
            <div class="icon-service">
               <img src="{{ asset('public/assets/user') }}/new-icon/diploma-visa.png" alt="visa-icon"> 
            </div>
            <div class="basciInfo">
               Simple Refugee content to popular Visa Lorem is not belief Country random visa
            </div>
            <a href="#"></a>
         </div>
      </div>
      <div class="item">
         <div class="insed-service">
            <h4>Job Seeker Visa</h4>
            <div class="icon-service">
               <img src="{{ asset('public/assets/user') }}/new-icon/family-visa.png" alt="visa-icon"> 
            </div>
            <div class="basciInfo">
               Global market with endless work opportunities for qualified workers 
            </div>
            <a href="#"></a>
         </div>
      </div>
      <div class="item">
         <div class="insed-service">
            <h4>Tourist  Visa</h4>
            <div class="icon-service">
               <img src="{{ asset('public/assets/user') }}/new-icon/tourist-visa.png" alt="visa-icon"> 
            </div>
            <div class="basciInfo">
               Tourist Visa to popular belief, Lorem Ipsum is not simply random text
            </div>
            <a href="#"></a>
         </div>
      </div>

   </div>
</div>
</div>
<div class="moreSomeArea">
   <div class="container">
      <div class="abt-info">
   <div class="row">
      <div class="col-md-6">
         <div class="themestek-wrap-cell">
            <!-- <h4 class="themestek-custom-heading ">Quick Contact Us</h4> -->
            <!-- <h2 class="themestek-custom-heading ">Free Online Visa Assessment<br>
               <em>In Any Type Of Visa</em>
            </h2> -->
             <h2><strong>Support </strong>You can count on</h2> 
         </div>
      </div>
      <div class="col-md-6">
         <div class="wpb_wrapper">
            <p>Contact us today by fill up free online visa assessment and we will contact you
               <a href="https://www.tripleibusiness.com/contact-us">Contact Us <span class="material-icons"><i class="fas fa-long-arrow-alt-right"></i></span></a>
            </p>
         </div>
      </div>
   </div>
   <div class="col-md-12">
      <ul>
         <li>
            <div class="insed-service2">
               <div class="icon-service">
               <span class="material-icons"><i class="fab fa-chromecast"></i></span>
            </div>
            <h4> Zoom/Skype Meetings</h4>
            
            <div class="basciInfo">
               Our support is not limited to calls or emails, we encourage our clients to fix the Zoom or Skype meeting for a detailed discussion regarding any query.
            </div>
            <a href="#"></a>
         </div>
         </li>
         <li>
            <div class="insed-service2">
               <div class="icon-service">
               <span class="material-icons"><i class="fas fa-street-view"></i></span>
            </div>
            <h4> Direct Visit</h4>
            
            <div class="basciInfo">
               We would love to meet you come and meet our experienced counselors to find solutions to your questions, our team will make sure to put a smile on your face. 
            </div>
            <a href="#"></a>
         </div>
         </li>
         <li>
            <div class="insed-service2">
               <div class="icon-service">
               <span class="material-icons"><i class="fas fa-mobile-alt"></i></span>
            </div>
            <h4> Call Facilities</h4>
            
            <div class="basciInfo">
               Our call support is available from Monday to Friday between 10 Am to 6 Pm.
            </div>
            <a href="#"></a>
         </div>
         </li>
         <li>
            <div class="insed-service2">
               <div class="icon-service">
               <span class="material-icons"><i class="fas fa-envelope-open-text"></i></span>
            </div>
            <h4>  E-Mail</h4>
            
            <div class="basciInfo">
               Response We are very active on emails and do not leave one email unattended, our email support replies within 1 business day to your queries 
            </div>
            <a href="#"></a>
         </div>
         </li>
         <li>
            <div class="insed-service2">
               <div class="icon-service">
               <span class="material-icons"><i class="fas fa-comments-dollar"></i></span>
            </div>
            <h4> Social Media</h4>
            
            <div class="basciInfo">
                Reach We reply within 24 hours, Evening and weekends may take a little longer to reply. 
            </div>
            <a href="#"></a>
         </div>
         </li>
      </ul>
   </div>
</div>

   </div>
</div>
</div>

@stop