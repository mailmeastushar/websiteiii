@extends('front.master')

@section("meta_title","Latest updates on Visa, Immigration & High paying Jobs")
    @section("meta_keywords","Blogs")
@section("meta_description","Check out the latest updates about visa processes and requirements to move to Canada, Australia, Germany, Newzealand, and the U.K")

@section('container')

<div class="blog_banner">
<div class="container-fluid">
<div class="row">
<img  src="{{ asset('public/assets/user') }}/images/91.jpg" alt="latest updates about visa immigration " class="img-responsive">
<div class="blog_heading">
<center><h6 class="animated fadeInLeft slower ">Triple I Business Services </h6></center>
<center><h2 class="animated zoomIn delay-1s slow">Latest News and Updates</h2></center>
</div>

</div>
</div>
</div>
<div class="blog_information">
<div class="container">
<div class="row">
@foreach($data as $data)

<div class="col-md-4 blockmargin">
    
<div class="card blog_card">
<a href="{{ route('detailblog',$data['seo_url']) }}">
<img src="{{ asset('public/assets/') }}/images/{{ $data['image'] }}" alt="{{ $data['alt'] }}" class="img-responsive" width="100%" height="200"></a>
<div class="card-body">
<a href="{{ route('detailblog',$data['seo_url']) }}"> <h4 class="card-title">{{ substr($data->name, 0,  20) }}...</h4></a>
<p class="card-text"><small class="text-muted"><i class="fa fa-calendar" aria-hidden="true"></i> {!! $data['updated_at'] !!}</small></p>

<div class="post-like-holder">
<a href="#" class="md-post-like" data-post_id="6304" title="Like">
<span class="like-heart"><i class="fa fa-heart" aria-hidden="true"></i>
</span> 
<!-- <span class="like-count">0
</span> -->
</a>                        
</div>
<button type="button" class="btn btn-danger">Immigration Services</button>
</div>
</a>
</div>
</div>


@endforeach
</div>
</div>
</div>
@endsection