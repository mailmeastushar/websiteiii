@extends('front/master')

@section("meta_title","Contact US | Triple I Business")
@section("meta_keywords","Triple I Busines Contact information, Triple I Business phone number, Triple I Business address,
Best immigration company in India")
@section("meta_description","Need help with your visa and immigration filing? contact our consultants to get started. Reach us at 011-465-207-36 or WhatsApp us at 859-574-4633")
@section('container')
<div class="contact_us">
<img src="{{ asset('public/assets/user/') }}/images/contact-us-banner-1.jpg" style="width: 100%;" class="img-responsive" alt="Triple I Business Image">
<div class="container cont_form_custom">

<div class="row">
<div class="col-md-8">
<form action="{{ url('addcontact/') }}" method="post">
{{ csrf_field() }}
<input class="form-control" name="name" placeholder="First Name..." /><br />
<input class="form-control" name="lname" placeholder="Last Name..." /><br />
<input class="form-control" name="mobile" placeholder="Phone..." /><br />
<input class="form-control" name="email" placeholder="E-mail..." /><br />
<textarea class="form-control" name="message" placeholder="How can we help you?" style="height:150px;"></textarea><br/>
<input class="btn btn-primary" type="submit" value="Send" /><br /><br />
</form>
</div>
<div class="col-md-4">
<b><i class="fa fa-map-marker" aria-hidden="true"></i> Address:</b> <br />
A-79 3rd floor DDA Shed Okhla Indusrial Area Phase-2 <br />
Near Crown Plaza Hotel,Delhi, INDIA<br />
<br /><br />
<b><i class="fa fa-phone" aria-hidden="true"></i> Phone:</b><br />
+91-8595744633<br />
+91-8595744633<br/><br />



<b><i class="fa fa-envelope-o" aria-hidden="true"></i> E-mail Us:</b><br/>

<a href="https://">info@tripleibusiness.com</a><br />


</div>
</div>
</div>
</div>



<!--Google map-->
<div style="width: 100%; margin-top: 20px;">
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28042.00589656729!2d77.2705318449691!3d28.532182280907698!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce79913f934e1%3A0x598e881f20623b1e!2sTriple%20I%20Business%20Services%20Pvt%20Ltd.!5e0!3m2!1sen!2sin!4v1598076568746!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

</div>




@stop