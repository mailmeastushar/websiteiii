

<!-- Footer -->
<footer class="page-footer font-small mdb-color pt-4 footer_custom" id="sticky-footer" 
style="background:#04131f;">
<div class="container text-center text-md-left">
<div class="row text-center text-md-left mt-3 pb-3">
<div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
<h6 class="text-uppercase mb-4 font-weight-bold" style="color: #fff">Address</h6>
<p >A-79 3rd floor DDA Shed Okhla Indusrial Area Phase-2 Near Crown Plaza Hotel,Delhi, INDIA</p>
<!--Google map-->
<div style="width: 100%; margin-top: 20px;">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28042.00589656729!2d77.2705318449691!3d28.532182280907698!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce79913f934e1%3A0x598e881f20623b1e!2sTriple%20I%20Business%20Services%20Pvt%20Ltd.!5e0!3m2!1sen!2sin!4v1598076568746!5m2!1sen!2sin" width="100%" height="110" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
</div>
</div>


<hr class="w-100 clearfix d-md-none">
<div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
<h6 class="text-uppercase mb-4 font-weight-bold" style="color: #fff">Know Us</h6>
<p><a href="{{ route('about-us') }}" style="color: #fff"><i class="fa fa-angle-double-right" aria-hidden="true"></i> About Us</a></p>
<p><a href="{{ route('harshit-rai') }}" style="color: #fff"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Our Offices</a></p>
<p><a href="{{ route('harshit-rai') }}" style="color: #fff"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Contact Us</a></p>
</div>

<hr class="w-100 clearfix d-md-none">
<div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
<h6 class="text-uppercase mb-4 font-weight-bold" style="color: #fff">Policies</h6>
<p><a href="{{ route('front_policy_gaurav','terms-condition') }}" style="color: #fff"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Terms of Use</a></p>
<p><a href="{{ route('front_policy_gaurav','privacy-policy') }}" style="color: #fff"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Privacy Policy</a></p>
<p><a href="{{ route('front_policy_gaurav','fraud-prevention') }}" style="color: #fff"><i class="fa fa-angle-double-right" aria-hidden="true"></i> Fraud Prevention</a></p>
</div>
<hr class="w-100 clearfix d-md-none">


<div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
<h6 class="text-uppercase mb-4 font-weight-bold" style="color: #fff">Contact</h6>
<p><i class="fa fa-envelope" aria-hidden="true"></i>info@tripleibusiness.com</p>
<p style="font-size: 0.8rem;"><i class="fa fa-phone" aria-hidden="true" 
style="color: #3f2ca9;font-weight: bold"></i> +011 46520736</p>
<p><a  href="https://web.whatsapp.com/" style="color: #fff;font-size: 0.8rem;">
<i class="fa fa-whatsapp" aria-hidden="true"style="color: #12BB1A;font-weight: bold"></i> +91 8595744633 </a>
</p>
</div>


</div>
<hr style="background: grey">
<div class="row d-flex align-items-center">
<div class="col-md-7 col-lg-8">
<p class="text-center text-md-left">© 2021 Copyright:
<a href="#" style="color: #fff">
<strong>Triple I Business Services  Pvt. Ltd. </strong>
</a>
</p>

</div>

<div class="col-md-5 col-lg-4 ml-lg-0">

<!-- Social buttons -->
<div class="text-center text-md-right Social_buttons">
<ul class="list-unstyled list-inline">
<li class="list-inline-item">
<a href="https://www.facebook.com/TripleIBusiness" class="btn-floating btn-sm  mx-1" style="background: #3A559F;border-radius: 50%;" target="_blank">
<i class="fa fa-facebook" aria-hidden="true"  style="color: #fff;"></i>
</a></li>

<li class="list-inline-item">
<a href="https://www.instagram.com/triplei_business" class="btn-floating btn-sm  mx-1" style="background: #4268B3;border-radius: 50%;" target="_blank">
<i class="fa fa-instagram" aria-hidden="true" style="color: #fff;"></i>
</a></li>

<li class="list-inline-item">
<a href="https://twitter.com/Tripleibusines" class="btn-floating btn-sm  mx-1" style="background: #4268B3;border-radius: 50%;" target="_blank">
<i class="fa fa-twitter" aria-hidden="true" style="color: #fff;"></i>
</a></li>

<li class="list-inline-item">
<a href="https://www.linkedin.com/company/tripleibusiness" class="btn-floating btn-sm  mx-1" style="background: #007AB9;border-radius: 50%;" target="_blank">
<i class="fa fa-linkedin" aria-hidden="true" style="color: #fff;"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</footer>
<!-- Footer -->




<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="{{ asset('public/toastr/toastr.js') }}"></script>
<script src="{{ asset('public/assets/user') }}/js/slider.js"></script>

<script type="text/javascript">
$(document).on('click', '.dropdown-menu', function (e) {
e.stopPropagation();
});

if ($(window).width() < 992) {
$('.dropdown-menu a').click(function(e){
// e.preventDefault();
if($(this).next('.submenu').length){
$(this).next('.submenu').toggle();
}
$('.dropdown').on('hide.bs.dropdown', function () {
$(this).find('.submenu').hide();
})
});
}

@if(Session::has("success"))
    toastr.success("{{ Session::get('success')}}");
@endif

@if(Session::has("danger"))
    toastr.error("{{ Session::get('danger')}}");
@endif

</script>
</body>
</html>