@extends('front.master')

@section("meta_title","Settle in Canada, Australia, NZ, Germany | Triple I Business")
@section("meta_keywords","Home")
@section("meta_description","Want to live abroad? Triple I Business is a leading Visa and immigration company in India. Apply for PR Visas, Study Visas, Work Visas in Canada, & Australia.")
@section('container')

<!-- ------slider start------- -->
<header>
<div class="owl-carousel owl-theme">

@foreach($slider as $slider)
<div class="item">
<img src="{{ asset('public/assets/images/'.$slider['image']) }}" alt="{{ $slider['alt'] }}" class="img-responsive">
<div class="cover">
<div class="container">
<div class="header-content">
<!-- <div class="line"></div> -->
<h2>{{ $slider['name']}}</h2>
</div>
</div>
</div>
</div> 
@endforeach

</div>
</header>
<!-- ------slider end//------- -->
<!-- ---fixed social media start----->
<div class="fixed_social_media">
<nav>
<ul>
        <li><a href="https://www.facebook.com/TripleIBusiness" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i><span>Facebook</span></a></li>
        <li><a href="https://twitter.com/Tripleibusines" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i><span>Twitter</span></a></li>
        <li><a href="https://www.instagram.com/triplei_business" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i><span>Instagram</span></a></li>
        <li><a href="https://www.linkedin.com/company/tripleibusiness" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i><span>Linkedin</span></a></li>
        <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i><span>Youtube</span></a></li>

</ul>
</nav>
</div>
<!-- ---fixed social media end//----->




<div class="countries_flag bottomMenu" style="background: #0f6775;" >
<div class="container">
<div class="row">

<div class="card-deck ">
<div class="card">
<center>
<img class="card-img-top" src="{{ asset('public/assets/user') }}/images/ca.png" alt="Card image cap" class="img-responsive">
</center>
<div class="card-body" style="padding: 0.3rem 0.64rem;">
<center><h6 class="card-title underline"  style="font-weight: bold;color: black;">CANADA</h6></center>
<h6 style="font-size: 0.77em;font-weight:bold "><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Strong Employment Market</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Healthcare Facilities</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Free International Education</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Social Security Benefits</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Multicultural Society </h6>



<button class="button"><a href="{{ url('visa/canada/benefits') }}"> <span>Know More </span></a></button>


</div>
</div>
<div class="card">
<center>
<img class="card-img-top" src="{{ asset('public/assets/user') }}/images/austrlia.png" alt="Card image cap" class="img-responsive">
</center>
<div class="card-body" style="padding: 0.3rem 0.64rem;">
<center><h6 class="card-title underline"  style="font-weight: bold;color: black;">AUSTRALIA</h6></center>
<h6 style="font-size: 0.77em;font-weight:bold "><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> First Home Owner Grantt</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Freedom to Work,Travel,Settle</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Pursue Higher Education</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Credit Rating</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Healthcare Entitlement </h6>


<button class="button"><a href="{{ url('visa/australia/benefits') }}"> <span>Know More </span></a></button>
</div>
</div>
<div class="card">
<center>
<img class="card-img-top" src="{{ asset('public/assets/user') }}/images/germany.png" alt="Card image cap" class="img-responsive">
</center>
<div class="card-body" style="padding: 0.3rem 0.33rem;">
<center><h6 class="card-title underline"  style="font-weight: bold;color: black;">GERMANY</h6></center>
<h6 style="font-size: 0.77em;font-weight:bold "><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Easy Hunt for a job</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Apply for Permanent Residency </h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Six-month Advantage</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> No pre-condition offer letter</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Get Germany Immigration </h6>


<button class="button"><a href="{{ url('visa/germany/benefits') }}"> <span>Know More </span></a></button>

</div>
</div>

<div class="card">
<center>
<img class="card-img-top" src="{{ asset('public/assets/user') }}/images/UK_flag.png" alt="Card image cap" class="img-responsive">
</center>
<div class="card-body" style="padding: 0.3rem 0.64rem;">
<center><h6 class="card-title underline"  style="font-weight: bold;color: black;">UK</h6></center>
<h6 style="font-size: 0.77em;font-weight:bold "><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Housing Benefits</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Apply for British Citizenship</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> HealthCare Benefits</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> International Education	</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Family can join you </h6>

<button class="button"><a href="{{ url('visa/uk/benefits') }}"> <span>Know More </span></a></button>

</div>
</div>

<div class="card">
<center>
<img class="card-img-top" src="{{ asset('public/assets/user') }}/images/austrlia.png" alt="Card image cap" class="img-responsive">
</center>
<div class="card-body" style="padding: 0.3rem 0.64rem;">
<center><h6 class="card-title underline"  style="font-weight: bold;color: black;">NEW ZEALAND</h6></center>
<h6 style="font-size: 0.77em;font-weight:bold "><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> No Restrictions</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> HealthCare Benefits</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> International Education</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> Voting Right</h6>
<h6 style="font-size: 0.77em;font-weight:bold"><i class="fa fa-circle" aria-hidden="true" style="font-size: 0.8em"></i> New Born Citizenship </h6>


<button class="button"><a href="{{ url('visa/newzealand/benefits') }}"> <span>Know More </span></a></button>

</div>
</div>
</div>
</div>
</div>
</div>


<!-- ------Running Updates start---- -->

<section id="breaking-news-container" class="full-width clearfix">
<div class="container">
<div class="breaking-news">
<div class="the_ticker">
<div class="bn-title">
<h5>Latest Updates</h5>
</div>
<div class="news-ticker">
<marquee behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();"
scrollamount="7" loop="infinite">
<ul>
@foreach($blog as $blog)
<li>
<i class="fa fa-angle-double-right"><a href="">{!! substr($blog['name'],0,15) !!}...</a></i>
</li>
@endforeach
</ul>
</marquee>
</div>
</div>
</div>
</div>
</section>

<!-- -------Running Updates end\\------ -->

<!-- ------------- -->
<div class="eligibilty_check">
<div class="container">
<h6 class="underline">CHECK YOUR ELIGIBILITY</h6>
<div class="card-deck">
<div class="card over">
<div class="card-body text-center">
<a href="{{ url('check/canada') }}">
<img src="{{ asset('public/assets/user') }}/images/ca.png" class="rounded float-left" alt="..." style="width: 30%" class="img-responsive">
<p class="card-text">CANADA</p>
</a>
</div>
</div>
<div class="card ">
<div class="card-body text-center">
<a href="{{ url('check/australia') }}">
<img src="{{ asset('public/assets/user') }}/images/austrlia.png" class="rounded float-left" alt="..." style="width: 30%" class="img-responsive">
<p class="card-text">AUSTRALIA</p>
</a>
</div>
</div>

<div class="card ">
<div class="card-body text-center">
<a href="{{ url('check/germany') }}">
<img src="{{ asset('public/assets/user') }}/images/germany.png" class="rounded float-left" alt="..." style="width: 30%" class="img-responsive">
<p class="card-text"> GERMANY</p>
</a>
</div>
</div>

<div class="card ">
<div class="card-body text-center">
<a href="{{ url('check/uk') }}">
<img src="{{ asset('public/assets/user') }}/images/UK_flag.png" class="rounded float-left" alt="..." style="width: 30%" class="img-responsive">
<p class="card-text">UK</p>
</a>
</div>
</div>

</div>
</div>
</div>



<div class="Subscribe">
<div class="container">
<div class="row">
<div class="col-sm-6">
<div class="tittle">
<h2><a href="blog" style="text-decoration:none;color:#fff">Stay tuned for latest updates </a><i class="fa fa-long-arrow-right" aria-hidden="true" style="color: #fff;font-size: 20px;"></i> </h2>
</div>
</div>

<div class="col-sm-6">
<form action="{{ url('newslatter/' )}}" method="get">
<div class="input-group">
<input type="email" name="email" class="form-control" placeholder="Enter your email" style="background-clip: unset;width: 40%;">
<span>
<button class="btn btn-theme" type="submit" style="color: #fff;
font-weight: bold;">Subscribe to our Newslatter</button>
</span>

</div>
</form>
</div>
</div>
</div>
</div>



<!-- -------//testimonial start//------ -->
<section class="testimonial_section">
<div class="container">
<div class="row">
<div class="col-lg-7">
<div class="about_content">
<div class="background_layer"></div>
<div class="layer_content">
<div class="section_title">
<h5>CLIENTS</h5>
<h2><strong>Support You can count on</strong></h2>
<div class="heading_line"><span></span></div>
<p>Our support team is available from Monday to Saturday between 10 Am to 6 Pm, you can also schedule a Zoom or Skype meeting and connect with us on Social Media Platform as well..</p>
</div>
<a href="{{ url('contact/') }}">Contact Us<i class="icofont-long-arrow-right"></i></a>
</div>
</div>
</div>
<div class="col-lg-5">
<div class="testimonial_box">
<div class="testimonial_container">
<div class="background_layer"></div>
<div class="layer_content">
<div class="testimonial_owlCarousel owl-carousel">


@foreach($testimonial as $testimonial)
<div class="testimonials"> 
<div class="testimonial_content">
<div class="testimonial_caption">
<h6>{{ $testimonial['name'] }}</h6>
<span>{{ $testimonial['post'] }}</span>
</div>
<p>{!! $testimonial['description'] !!}</p>
</div>
<div class="images_box">
<div class="testimonial_img">
<img class="img-center" src="{{ asset('public/assets/images/'.$testimonial['image']) }}" alt="{{ $testimonial['alt'] }}">
</div>
</div>
</div>
@endforeach
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- testimonial end// -->

<!-- --------//popup box//------ -->
<div id="boxes" style="background-color: #0f6775;">
<div style="margin-top: 50px;" id="dialog" class="window" style="background-color: #0f6775;"> 
<div id="san" style="background-color: #0f6775;">
<a href="#" class="close agree"><img src="{{ asset('public/assets/user') }}/images/close-icon.png" width="25" style="float:right; margin-right: -25px; margin-top: -20px;" class="img-responsive"></a>
<div class="container" style="background-color: #0f6775;">
<div class="row" style="background-color: #0f6775;">
<!-- 
<div class="col-lg-8 col-lg-offset-2"> -->
<h5>GET IN TOUCH</h5>

<form action="{{ url('addcontact/') }}" method="post" role="form">
{{ csrf_field() }}
<div class="messages"></div>

<div class="controls">

<div class="row">
<div class="col-md-6">
<div class="form-group fg">
<!-- <label for="form_name">Firstname *</label> -->
<input id="form_name" type="text" name="name" class="form-control" placeholder="First Name *" required="required" data-error="Firstname is required.">
<div class="help-block with-errors"></div>
</div>
</div>
<div class="col-md-6">
<div class="form-group fg">
<!-- <label for="form_lastname">GET IN TOUCH</label> -->
<input id="form_lastname" type="text" name="lname" class="form-control" placeholder="Last Name *" required="required" data-error="Lastname is required.">
<div class="help-block with-errors"></div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group fg">
<!--  <label for="form_email">Your Email *</label> -->
<input id="form_email" type="email" name="email" class="form-control" placeholder="Email *" required="required" data-error="Valid email is required.">
<div class="help-block with-errors"></div>
</div>
</div>
<div class="col-md-6">
<div class="form-group fg">
<!-- <label for="form_phone">Phone</label> -->
<input id="form_phone" type="tel" name="mobile" class="form-control" placeholder="Phone *">
<div class="help-block with-errors"></div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group fg">
<!--     <label for="form_message">Message *</label> -->
<textarea id="form_message" name="message" class="form-control" placeholder="Your message " rows="4" required data-error="Please,leave us a message."></textarea>
<div class="help-block with-errors"></div>
</div>
</div>
<div class="col-md-12 con_custom">
<input type="submit" class="btn  btn-primary" value="SEND MESSAGE">
</div>
</div>

</div>

</form>

<!--   </div> -->
</div>
</div>
</div>
</div>

</div>

<!-- --------//popup box end//------ -->

@endsection
